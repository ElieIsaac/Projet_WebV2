<?php

	$style = "Content/Style.css";
	$title = "Vue";
	$onload = '';

	if($typeVue == "vuePMA")
	{
		require_once('DataPMA.php');
	}