<?php
	$style = "Content/StylePMA.css";
	$title = "Vue PMA";

	$onload = 'onload="Init()"';

	$header = 'HeaderPMA.php';
	$main = 'MainPMA.php';
	$footer = 'FooterPMA.php';
?>
