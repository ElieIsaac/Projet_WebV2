<?php
	echo '<meta charset = "utf-8" />';
	echo '<link rel = "stylesheet" type = "text/css" href = '.$style.' />';
	echo '<title>'.$title.'</title>' ;
?>