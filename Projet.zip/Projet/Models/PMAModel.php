<?php

class PMAModel extends Model
{
	// SELECT les �l�ments de la table VICTIME
	public function GetVictimes()
	{
		$this->getBdd();
		$query = parent::$_bdd->query('SELECT * FROM VICTIME');

		/*
		while ($data = $query->fetch()){
			echo $data['ID'];
			echo "</br>";
			echo $data['NOM'];
			echo "</br>";
			echo $data['PRENOM'];
			echo "</br>";
			echo $data['VIE']." PV";
			echo "</br>";

			echo "</br>";
		}
		return $query;
		*/

		$victimes = $query->fetchAll();

		// On ferme la requete sql
		$query->closeCursor();
		echo json_encode($victimes);
	}

	// DELETE un �l�ment de la table VICTIME
	public function DelVictime($nom,$prenom)
	{
		$this->getBdd();
		$query = parent::$_bdd->prepare('DELETE FROM VICTIME WHERE VICTIME.NOM = ? AND VICTIME.PRENOM = ?;');
		$query->execute(array($nom, $prenom));
		$query->closeCursor();

		echo json_encode(["status" => "success"]);
	}

	// INSERT des �l�ments dans la ou les table(s) EVAC
	public function SendToEvac($nom,$prenom,$blessures)
	{

		// 0 l�g�res, 1 graves
		$this->getBdd();
		$query = parent::$_bdd->prepare('INSERT INTO victims (NOM, PRENOM, VIVANT, VIE, CHARGE, BLESSURES) VALUES (?, ?, 1, 100, 1, ?);');
        $query->execute(array($nom, $prenom,$blessures));
		$query->closeCursor();

		echo json_encode(["status" => "success"]);
	}

}
