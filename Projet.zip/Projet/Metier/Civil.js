class Civil extends Personne{

    constructor(id) {
        super(id);
    }  

}

